#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "FusionDestiny.h"

#define SIZE 1000

TheStu* StudentFusion(void)
{

    static TheStu Drgn[SIZE]={0};
    static TheStu* pDrgn = Drgn;

    register int i;

    FILE* fpName = NULL;
    FILE* fpNum = NULL;
    FILE* fpGrade = NULL;
    FILE* fpScore = NULL;
    FILE* fpScoreM = NULL;
    FILE* fpMajor = NULL;


    fpName = fopen("Student_Name.txt", "a+");
    fpNum = fopen("Student_Number.txt", "a+");
    fpGrade = fopen("Student_Grade.txt", "a+");
    fpMajor = fopen("Student_Major.txt", "a+");
    fpScore = fopen("Student_Score.txt", "a+");
    fpScoreM = fopen("Student_ScoreM.txt", "a+");
    

    for (i = 0; i < SIZE; i++) {
        fscanf(fpNum, "%d", &Drgn[i].TheNum);

        fscanf(fpGrade, "%d", &Drgn[i].TheGrade);
      
        fscanf(fpName, "%s", &Drgn[i].TheName);

        fscanf(fpMajor, "%d", &Drgn[i].TheMajor);

        fscanf(fpScore, "%f", &Drgn[i].TheScore);

        fscanf(fpScoreM, "%f", &Drgn[i].TheMj_Score);

    }
   



    fclose(fpName);
    fclose(fpNum);
    fclose(fpGrade);
    fclose(fpScore);
    fclose(fpScoreM);
    fclose(fpMajor);

    return pDrgn;

}
