﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

/*
과목별로 과목 이름과 학생 정보, 학점을 데이터로.
일단 다른 소스파일 데이터를 가져올 수 있는지부터 테스트해보자.
*/

int main(void)
{
    
    
    return 0;
}

